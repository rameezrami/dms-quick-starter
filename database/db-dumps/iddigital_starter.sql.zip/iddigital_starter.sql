-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 06, 2018 at 03:36 PM
-- Server version: 5.7.23-0ubuntu0.16.04.1
-- PHP Version: 7.0.30-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iddigital_starter`
--

-- --------------------------------------------------------

--
-- Table structure for table `content_groups`
--

CREATE TABLE `content_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `namespace` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_index` int(11) NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `content_groups`
--

INSERT INTO `content_groups` (`id`, `parent_id`, `namespace`, `name`, `order_index`, `updated_at`) VALUES
(2, NULL, 'home', 'seo', 1, '2018-07-31 07:07:51'),
(5, NULL, 'settings', 'contact-details', 1, '2018-08-06 09:58:11'),
(6, NULL, 'settings', 'social-links', 2, '2018-08-06 09:57:41');

-- --------------------------------------------------------

--
-- Table structure for table `content_group_file_areas`
--

CREATE TABLE `content_group_file_areas` (
  `id` int(10) UNSIGNED NOT NULL,
  `content_group_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `content_group_html_areas`
--

CREATE TABLE `content_group_html_areas` (
  `id` int(10) UNSIGNED NOT NULL,
  `content_group_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `html` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `content_group_image_areas`
--

CREATE TABLE `content_group_image_areas` (
  `id` int(10) UNSIGNED NOT NULL,
  `content_group_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alt_text` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `content_group_metadata`
--

CREATE TABLE `content_group_metadata` (
  `id` int(10) UNSIGNED NOT NULL,
  `content_group_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `content_group_text_areas`
--

CREATE TABLE `content_group_text_areas` (
  `id` int(10) UNSIGNED NOT NULL,
  `content_group_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `content_group_text_areas`
--

INSERT INTO `content_group_text_areas` (`id`, `content_group_id`, `name`, `text`) VALUES
(4, 2, 'title', ''),
(5, 2, 'description', ''),
(6, 2, 'keywords', ''),
(30, 6, 'facebook_link', ''),
(31, 6, 'twitter_link', ''),
(32, 6, 'linked_in_link', ''),
(33, 6, 'google_plus_link', ''),
(34, 6, 'youtube_link', ''),
(35, 6, 'skype_link', ''),
(36, 6, 'blog_link', ''),
(53, 5, 'business_name', ''),
(54, 5, 'enquiry_email_address', ''),
(55, 5, 'phone_number', ''),
(56, 5, 'address_1', ''),
(57, 5, 'address_2', ''),
(58, 5, 'suburb', ''),
(59, 5, 'state', ''),
(60, 5, 'post_code', '');

-- --------------------------------------------------------

--
-- Table structure for table `dms_analytics`
--

CREATE TABLE `dms_analytics` (
  `id` int(10) UNSIGNED NOT NULL,
  `driver` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dms_password_resets`
--

CREATE TABLE `dms_password_resets` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dms_permissions`
--

CREATE TABLE `dms_permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dms_roles`
--

CREATE TABLE `dms_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dms_temp_files`
--

CREATE TABLE `dms_temp_files` (
  `id` int(10) UNSIGNED NOT NULL,
  `token` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('uploaded-image','uploaded-file','stored-image','in-memory','stored-file') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:CustomEnum__uploaded_image__uploaded_file__stored_image__in_memory__stored_file)',
  `expiry_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dms_temp_files`
--

INSERT INTO `dms_temp_files` (`id`, `token`, `file`, `client_file_name`, `type`, `expiry_time`) VALUES
(1, 'h17t2xEXgmOkv61PKf5OiKx5SSIWzMDIuvdhKrJ3', '/', NULL, 'stored-file', '2018-08-06 10:08:54'),
(2, 'GNmrjKWGdxo09mRisMPmAsEKYcHMo9WjSSv8C91T', '/', NULL, 'stored-file', '2018-08-06 10:57:49'),
(3, 'pC5wmIYoplPcWmbj5ww8qM77TkFNcfVR06jKCw1L', '/home/dev249/projects/IDDIGITAL/DMS-STARTER/storage/dms/temp-uploads/93W0Jx0UlmQezoMdj6VXmAL8kjY0Z8xA', 'iddigital_maddernfinancial(31-07-18).sql.zip', 'stored-file', '2018-08-06 10:58:05'),
(4, 'NnJthoIV4K8reFIdJbvdgOMG1jvBHjUf8ThhXQgd', '/home/dev249/projects/IDDIGITAL/DMS-STARTER/public/app/content/files/settings/biography_pdf_f7e87dfa86f2.zip', 'iddigital_maddernfinancial(31-07-18).sql.zip', 'stored-file', '2018-08-06 10:58:08'),
(5, 'IQ00qQpUO24xSUIUyl9Nv9PLaEicqNA60FsuL0wb', '', NULL, 'stored-file', '2018-08-06 10:58:11');

-- --------------------------------------------------------

--
-- Table structure for table `dms_users`
--

CREATE TABLE `dms_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` enum('local','oauth') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:CustomEnum__local__oauth)',
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_super_user` tinyint(1) NOT NULL,
  `is_banned` tinyint(1) NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_algorithm` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_cost_factor` int(11) DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oauth_provider_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oauth_account_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dms_users`
--

INSERT INTO `dms_users` (`id`, `type`, `full_name`, `email`, `username`, `is_super_user`, `is_banned`, `password_hash`, `password_algorithm`, `password_cost_factor`, `remember_token`, `oauth_provider_name`, `oauth_account_id`, `metadata`) VALUES
(2, 'local', 'Admin', 'admin@admin.com', 'admin', 1, 0, '$2y$10$IA0LKBWfDYtfe8C903uCoeK6reqoviBQXneMgVeW77qSNVKwqpsBm', 'bcrypt', 10, NULL, NULL, NULL, '[]');

-- --------------------------------------------------------

--
-- Table structure for table `dms_user_roles`
--

CREATE TABLE `dms_user_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `js_snippet_codes`
--

CREATE TABLE `js_snippet_codes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `js_code` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_07_31_061308_initial_db', 1),
(2, '2018_07_31_064911_content_groups', 2),
(3, '2018_07_31_070453_js_snippet_codes', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `content_groups`
--
ALTER TABLE `content_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_985B49DC727ACA70` (`parent_id`);

--
-- Indexes for table `content_group_file_areas`
--
ALTER TABLE `content_group_file_areas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `content_group_file_unique_index` (`content_group_id`,`name`),
  ADD KEY `IDX_9DC2122BACE333A8` (`content_group_id`);

--
-- Indexes for table `content_group_html_areas`
--
ALTER TABLE `content_group_html_areas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `content_group_html_unique_index` (`content_group_id`,`name`),
  ADD KEY `IDX_87B6C2F3ACE333A8` (`content_group_id`);

--
-- Indexes for table `content_group_image_areas`
--
ALTER TABLE `content_group_image_areas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `content_group_images_unique_index` (`content_group_id`,`name`),
  ADD KEY `IDX_39468675ACE333A8` (`content_group_id`);

--
-- Indexes for table `content_group_metadata`
--
ALTER TABLE `content_group_metadata`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `content_group_metadata_unique_index` (`content_group_id`,`name`),
  ADD KEY `IDX_2CCF82BFACE333A8` (`content_group_id`);

--
-- Indexes for table `content_group_text_areas`
--
ALTER TABLE `content_group_text_areas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `content_group_text_unique_index` (`content_group_id`,`name`),
  ADD KEY `IDX_61F51841ACE333A8` (`content_group_id`);

--
-- Indexes for table `dms_analytics`
--
ALTER TABLE `dms_analytics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dms_password_resets`
--
ALTER TABLE `dms_password_resets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `dms_password_resets_token_unique_index` (`token`);

--
-- Indexes for table `dms_permissions`
--
ALTER TABLE `dms_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_2B0D74A1D60322AC` (`role_id`);

--
-- Indexes for table `dms_roles`
--
ALTER TABLE `dms_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dms_temp_files`
--
ALTER TABLE `dms_temp_files`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `dms_temp_files_token_unique_index` (`token`);

--
-- Indexes for table `dms_users`
--
ALTER TABLE `dms_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `dms_users_email_unique_index` (`email`),
  ADD UNIQUE KEY `dms_users_username_unique_index` (`username`);

--
-- Indexes for table `dms_user_roles`
--
ALTER TABLE `dms_user_roles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_2F104DAD60322AC` (`role_id`),
  ADD KEY `IDX_2F104DAA76ED395` (`user_id`);

--
-- Indexes for table `js_snippet_codes`
--
ALTER TABLE `js_snippet_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `content_groups`
--
ALTER TABLE `content_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `content_group_file_areas`
--
ALTER TABLE `content_group_file_areas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `content_group_html_areas`
--
ALTER TABLE `content_group_html_areas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `content_group_image_areas`
--
ALTER TABLE `content_group_image_areas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `content_group_metadata`
--
ALTER TABLE `content_group_metadata`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `content_group_text_areas`
--
ALTER TABLE `content_group_text_areas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `dms_analytics`
--
ALTER TABLE `dms_analytics`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dms_password_resets`
--
ALTER TABLE `dms_password_resets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dms_permissions`
--
ALTER TABLE `dms_permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dms_roles`
--
ALTER TABLE `dms_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dms_temp_files`
--
ALTER TABLE `dms_temp_files`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `dms_users`
--
ALTER TABLE `dms_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `dms_user_roles`
--
ALTER TABLE `dms_user_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `js_snippet_codes`
--
ALTER TABLE `js_snippet_codes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `content_groups`
--
ALTER TABLE `content_groups`
  ADD CONSTRAINT `fk_content_groups_parent_id_content_groups` FOREIGN KEY (`parent_id`) REFERENCES `content_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `content_group_file_areas`
--
ALTER TABLE `content_group_file_areas`
  ADD CONSTRAINT `fk_content_group_file_areas_content_group_id_content_groups` FOREIGN KEY (`content_group_id`) REFERENCES `content_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `content_group_html_areas`
--
ALTER TABLE `content_group_html_areas`
  ADD CONSTRAINT `fk_content_group_html_areas_content_group_id_content_groups` FOREIGN KEY (`content_group_id`) REFERENCES `content_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `content_group_image_areas`
--
ALTER TABLE `content_group_image_areas`
  ADD CONSTRAINT `fk_content_group_image_areas_content_group_id_content_groups` FOREIGN KEY (`content_group_id`) REFERENCES `content_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `content_group_metadata`
--
ALTER TABLE `content_group_metadata`
  ADD CONSTRAINT `fk_content_group_metadata_content_group_id_content_groups` FOREIGN KEY (`content_group_id`) REFERENCES `content_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `content_group_text_areas`
--
ALTER TABLE `content_group_text_areas`
  ADD CONSTRAINT `fk_content_group_text_areas_content_group_id_content_groups` FOREIGN KEY (`content_group_id`) REFERENCES `content_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `dms_permissions`
--
ALTER TABLE `dms_permissions`
  ADD CONSTRAINT `fk_dms_permissions_role_id_dms_roles` FOREIGN KEY (`role_id`) REFERENCES `dms_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `dms_user_roles`
--
ALTER TABLE `dms_user_roles`
  ADD CONSTRAINT `fk_dms_user_roles_role_id_dms_roles` FOREIGN KEY (`role_id`) REFERENCES `dms_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_dms_user_roles_user_id_dms_users` FOREIGN KEY (`user_id`) REFERENCES `dms_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
